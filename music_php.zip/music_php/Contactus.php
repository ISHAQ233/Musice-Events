<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@100&display=swap" rel="stylesheet">
    <title>RKMusic</title>
</head>
<body>


<?php

$host='localhost';
$root='root';
$pass='';
$db='Pakistan';
$conn = mysqli_connect($host,$root,$pass,$db) or die('Cannot connect to database');
if(isset($_POST['submit'])){

$username=trim(mysqli_real_escape_string($conn,$_POST['name']));
$useremail=trim(mysqli_real_escape_string($conn,$_POST['email']));
$usermobile=trim(mysqli_real_escape_string($conn,$_POST['mobile']));
$usercomments=trim(mysqli_real_escape_string($conn,$_POST['comments']));
$dup=mysqli_query($conn,"select * from pakistandata where UserName='$username' ");

if(mysqli_num_rows($dup)>0)
{
  echo "It is Duplicated Values Not Enter";
}
else{
}
$inserq= "insert into pakistandata(UserName,UserEmail,UserMobile,UserComments) values('$username','$useremail','$usermobile','$usercomments')";
if(mysqli_query($conn,$inserq)){
echo "inserted Data Successfully";
header("location:Contactus.php");
}else{
  echo "Not Inserted Data";
  header("location:about.php");
}
}
?>
















<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <a class="navbar-brand" href="#">RKMusic</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="services.php">Services</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About Us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Contactus.php">Contact Us</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<div style="margin-top:0px"></div>
<div class="container-fluid margin-top-5">
 <div class="text-center ">
</div>
</div>



<section class="my-5">
<div class="py-5">
<h2 class="text-center">Contact Us</h2>
</div>
<div class="w-50 m-auto">
<form action="#" method="POST">
    <div class="form-group">
        <label >UserName</label>
        <input type="text" name="name" autocomplete="off" class="form-control">

    </div>
    <div class="form-group">
        <label >UserEmail</label>
        <input type="text" name="email" autocomplete="off" class="form-control">

    </div>
    <div class="form-group">
        <label >UserMobileNo</label>
<input type="text" name="mobile" autocomplete="off" class="form-control">
</div>
<div class="form-group">
<label >Comments</label>
<textarea name="comments"  class="form-control"></textarea>
</div>
<input type="submit" name="submit" value="submit" class="btn btn-success">
</form>
</div>
</section>
<footer>
<p class="p-3 bg-dark text-white text-center">Devloped by Ishaq Mahar @Copyright 2020</p>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> 

</body>
</html>