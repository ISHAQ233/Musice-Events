<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@100&display=swap" rel="stylesheet">
    <title>RKMusic</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <a class="navbar-brand" href="#">RKMusic</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="services.php">Services</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About Us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Contactus.php">Contact Us</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<div style="margin-top:0px"></div>
<div class="container-fluid margin-top-5">
 <div class="text-center ">
</div>
</div>
<section class="my-5">
<div class="py-5">
<h2 class="text-center">About Us</h2>
</div>
<div class="container-fluid">
<div class="row">
<div class="col-lg-6 col-md-6 col-12 ">
<img src="img/3.jpg" class="img-fluid aboutimg">
</div>
<div class="col-lg-6 col-md-6 col-12 ">
<h2 class="display-5" >Music Events</h1>
<p class="py-3">The Best Way To Get Your Free Musician Website Online We provide pages like Bandsintown, 
Soundcloud, and music player, so you can use all of these services and make a multi-layered
music website. You can upload your music for free sharing and downloading, or sell it digitally
with a premium account</p>
<a href="about.php" class="btn btn-success">Read More</a>
</div>
</div>
</div>
</section>


<section class="my-5">
<div class="py-5">
<h2 class="text-center">Music Night</h2>
</div>
<div class="container-fluid">
<div class="row">
<div class="col-lg-6 col-md-6 col-12 ">
<img src="img/17.jpg" class="img-fluid aboutimg">
</div>
<div class="col-lg-6 col-md-6 col-12 ">
<h2 class="display-5" >Music Events</h1>
<p class="py-3">The Best Way To Get Your Free Musician Website Online We provide pages like Bandsintown, 
Soundcloud, and music player, so you can use all of these services and make a multi-layered
music website. You can upload your music for free sharing and downloading, or sell it digitally
with a premium account</p>
<a href="about.php" class="btn btn-success">Read More</a>
</div>
</div>
</div>
</section>







<footer>
<p class="p-3 bg-dark text-white text-center">Devloped by Ishaq Mahar @Copyright 2020</p>
</footer>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> 


</body>
</html>